$(function() {
    $("#rechnen").click(function(){
      var rechnen=2*2;
      $("#ausgabe").text(rechnen);
    })
})
